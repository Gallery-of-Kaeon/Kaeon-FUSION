package test;

import java.util.ArrayList;

import one.Element;
import one_plus.directive.Directive;

public class Test extends Directive {
	
	public void apply(
			ArrayList<Directive> directiveUnits,
			ArrayList<Element> directives,
			Element element) {
		
		if(element.content.equalsIgnoreCase("TEST"))
			apply(directives, element.parent);
	}
	
	public void apply(ArrayList<Element> directives, Element element) {
		
		for(int i = 0; i < element.children.size(); i++) {
			
			Element child = element.children.get(i);
			
			if(!isDirective(directives, child))
				child.content = "TEST - " + child.content;
			
			apply(directives, child);
		}
	}
	
	public boolean isDirective(ArrayList<Element> directives, Element element) {
		
		for(int i = 0; i < directives.size(); i++) {
			
			if(directives.get(i) == element)
				return true;
		}
		
		return false;
	}
}